plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.film.capybaratoolkit"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.film.capybaratoolkit"
        minSdk = 26
        targetSdk = 28
        versionCode = 2
        versionName = "2.0-film"
    }
    kotlinOptions { jvmTarget = "17" }
}
