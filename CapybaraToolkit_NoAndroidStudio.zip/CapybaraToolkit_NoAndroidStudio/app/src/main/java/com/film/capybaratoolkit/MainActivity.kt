package com.film.capybaratoolkit

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 70, 48, 40)
            setBackgroundColor(Color.rgb(12,16,18))
        }
        fun text(t:String, size:Float) = TextView(this).apply { text=t; textSize=size; setTextColor(Color.rgb(210,255,225)) }
        root.addView(text("CAPYBARA TOOLKIT", 25f))
        root.addView(text("FILM PROP // OVERLAY SYSTEM\n\nPainel visual para gravação. Não modifica outros aplicativos ou jogos.", 14f))
        val permit = Button(this).apply { text="1  AUTORIZAR OVERLAY"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }}
        val start = Button(this).apply { text="2  INICIAR PAINEL"; setOnClickListener {
            if (Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity, OverlayService::class.java))
            else Toast.makeText(this@MainActivity,"Autorize o overlay primeiro",Toast.LENGTH_SHORT).show()
        }}
        val stop = Button(this).apply { text="PARAR PAINEL"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) } }
        root.addView(permit); root.addView(start); root.addView(stop)
        setContentView(root)
    }
}
