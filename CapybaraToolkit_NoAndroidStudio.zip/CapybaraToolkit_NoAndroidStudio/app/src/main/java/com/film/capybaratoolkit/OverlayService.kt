package com.film.capybaratoolkit

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null

    override fun onCreate() { super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager; showBubble() }
    private fun bg(c:Int,r:Float=26f)=GradientDrawable().apply{setColor(c);cornerRadius=r;setStroke(2,Color.rgb(70,255,170))}
    private fun params(w:Int,h:Int)=WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=20;y=260}

    private fun showBubble(){
        val p=params(135,135)
        val v=TextView(this).apply{text="C";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=bg(Color.rgb(18,24,27),70f)}
        var ix=0;var iy=0;var tx=0f;var ty=0f;var moved=false
        v.setOnTouchListener { _,e -> when(e.action){
            MotionEvent.ACTION_DOWN->{ix=p.x;iy=p.y;tx=e.rawX;ty=e.rawY;moved=false;true}
            MotionEvent.ACTION_MOVE->{if(kotlin.math.abs(e.rawX-tx)>8||kotlin.math.abs(e.rawY-ty)>8)moved=true;p.x=ix+(e.rawX-tx).toInt();p.y=iy+(e.rawY-ty).toInt();wm.updateViewLayout(v,p);true}
            MotionEvent.ACTION_UP->{if(!moved){if(panel==null)showPanel() else hidePanel()};true}
            else->false }}
        bubble=v;wm.addView(v,p)
    }

    private fun showPanel(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,22,24,22);background=bg(Color.argb(247,10,15,17))}
        val title=TextView(this).apply{text="CAPYBARA TOOLKIT // v2.0";textSize=17f;setTextColor(Color.rgb(70,255,170))}
        val status=TextView(this).apply{text="TARGET: CAPYBARA GO\nLINK: READY\nSTATUS: STANDBY";textSize=12f;setTextColor(Color.LTGRAY)}
        val log=TextView(this).apply{text="[boot] module loaded\n[scan] waiting for scene command...";textSize=11f;setTextColor(Color.rgb(170,255,200));setPadding(0,10,0,10)}
        fun action(label:String,msg:String)=Button(this).apply{text=label;setOnClickListener{log.append("\n> $msg")}}
        root.addView(title);root.addView(status)
        root.addView(action("ATTACH // SIMULATE","[link] target attached (visual simulation)"))
        root.addView(action("COINS +999K","[wallet] coin visual override staged"))
        root.addView(action("GEMS +99K","[wallet] gem visual override staged"))
        root.addView(action("DAMAGE x99","[combat] multiplier staged"))
        root.addView(action("SPEED x4","[engine] speed flag staged"))
        root.addView(action("GOD MODE","[combat] protection flag staged"))
        root.addView(Button(this).apply{text="TRIGGER DETECTION";setOnClickListener{status.text="TARGET: CAPYBARA GO\nLINK: INTERRUPTED\nSTATUS: ANOMALOUS ACTIVITY DETECTED";log.append("\n[warn] integrity monitor response detected")}})
        root.addView(Button(this).apply{text="RESET SCENE";setOnClickListener{status.text="TARGET: CAPYBARA GO\nLINK: READY\nSTATUS: STANDBY";log.text="[boot] module loaded\n[scan] waiting for scene command..."}})
        root.addView(log)
        root.addView(Button(this).apply{text="CLOSE";setOnClickListener{hidePanel()}})
        val p=params(760,WindowManager.LayoutParams.WRAP_CONTENT).apply{x=150;y=120}
        panel=root;wm.addView(root,p)
    }
    private fun hidePanel(){panel?.let{wm.removeView(it);panel=null}}
    override fun onDestroy(){hidePanel();bubble?.let{wm.removeView(it);bubble=null};super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
