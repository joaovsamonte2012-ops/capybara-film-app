CAPYBARA TOOLKIT — GERAR APK SEM ANDROID STUDIO

O app é um overlay visual para filmagem. Ele NÃO modifica o Capybara Go nem outros aplicativos.

MÉTODO SEM ANDROID STUDIO:
1. Crie um repositório vazio no GitHub.
2. Envie TODO o conteúdo desta pasta para o repositório, inclusive a pasta .github.
3. Abra a aba Actions do repositório.
4. Abra “Build APK”.
5. Clique em “Run workflow”.
6. Quando o build concluir, abra a execução e baixe o artefato “CapybaraToolkit-APK”.
7. Extraia o ZIP do artefato: dentro estará app-debug.apk.
8. Passe o APK para seu Android e instale.
9. Abra o app, autorize “Aparecer sobre outros apps” e toque em INICIAR PAINEL.

O APK gerado é para uso de teste/filmagem, não é uma versão de Play Store.
